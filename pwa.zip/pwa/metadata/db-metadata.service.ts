import { Injectable } from '@angular/core';
import { EntityMetadata, EntityMetadataCatelog } from './db-metadata';
import { MetadataKeys } from './db-metadata.constant';
import { DBTables } from '../db-tables.constant';


@Injectable({ providedIn: 'root' })
export class MetadataService {
  private catalog: EntityMetadataCatelog = {
    // [MetadataKeys.ProjectList]: {
    //   primaryKey: 'id',
    //   dbTableName: DBTables.Project,
    //   relations: [
    //     {
    //       mappingMetadata: {
    //         dbTableName: DBTables.ProjectMember,
    //         parentPrimaryKey: 'project_id',
    //         childPrimaryKey: 'user_id',
    //       },
    //       dbTableName: DBTables.User,
    //       primaryKey: 'user_id',
    //       apiKey: 'member_list',
    //     },
    //   ]
    // },
    // ... other keys ...
  };

  getMetadata(key: MetadataKeys): EntityMetadataHandler {
    const metadata = this.catalog[key];
    if (!metadata) {
      throw new Error(`Metadata not found for key: ${key}`);
    }
    return new EntityMetadataHandler(metadata);
  }
}

export class EntityMetadataHandler {
  metadata: EntityMetadata;
  constructor(metadata: EntityMetadata) {
    this.metadata = metadata;
  }

  getAllTablesName(): string[] {
    const tables: Set<string> = new Set();
    tables.add(this.metadata.dbTableName);
    if (this.metadata.relations) {
      this.metadata.relations.forEach(relation => {
        tables.add(relation.dbTableName);
        if (relation.mappingMetadata.dbTableName) {
          tables.add(relation.mappingMetadata.dbTableName);
        }
      });
    }
    return Array.from(tables);
  }
}
