
export interface EntityMetadata {
  dbTableName: string;
  primaryKey: string;
  apiKey?: string;
  relations?: RelationMetadata[];
}

export interface RelationMetadata {
  dbTableName: string;
  primaryKey: string;
  apiKey?: string;
  mappingMetadata: {
    dbTableName: string;
    parentPrimaryKey: string;
    childPrimaryKey: string;
  }
}

export interface EntityMetadataCatelog {
  [key: string]: EntityMetadata;
}