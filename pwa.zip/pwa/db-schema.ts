import { DBTables } from './db-tables.constant';

interface IndexDefinition {
  name: string; // The name of the index (e.g., 'title')
  keyPath: string | string[]; // The path to the field in the object (e.g., 'title')
  options?: IDBIndexParameters; // IndexedDB index options
}

interface ObjectStoreDefinition {
  name: DBTables; // The name of the object store (e.g., DBTables.Project)
  options: IDBObjectStoreParameters; // IndexedDB object store options
  indexes: IndexDefinition[]; // Array of index definitions
}

// --- Define the Database Schema Metadata ---
export const INDEXDB_SCHEMA: ObjectStoreDefinition[] = [
  {
    name: DBTables.DentalCode,
    options: { keyPath: 'code', autoIncrement: false },
    indexes: [],
  },
  {
    name: DBTables.DataSyncStatus,
    options: { keyPath: 'id', autoIncrement: true },
    indexes: [],
  }
];