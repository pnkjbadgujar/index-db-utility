
export enum DBTables {
  DentalCode = 'DentalCode',
  DataSyncStatus = 'DataSyncStatus'
}
