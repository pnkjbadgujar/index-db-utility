// Define a type for the filter arguments
export interface IndexFilter {
  indexName: string; // The name of the index to use (e.g., 'project_id', 'title')
  keyRange: IDBValidKey | IDBKeyRange; // The key or range to filter by
}