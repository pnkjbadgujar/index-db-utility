import { inject, Injectable } from '@angular/core';
import { DbService } from './db.service';
import { MetadataKeys } from '../metadata/db-metadata.constant';
import { EntityMetadataHandler, MetadataService } from '../metadata/db-metadata.service';
import { IndexFilter } from './db-filter';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DBTableService {
  private readonly dbService = inject(DbService);
  private readonly metadataService = inject(MetadataService);

  /**
   * Private helper to execute an IndexedDB transaction.
   * Promotes the Unit of Work principle.
   */
  private async _executeTransaction<T>(
    tableNames: string[],
    mode: IDBTransactionMode,
    callback: (transaction: IDBTransaction) => void
  ): Promise<T> {
    const db = await this.dbService.getDb();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(tableNames, mode);
      let result: T; // Capture result from callback

      transaction.oncomplete = () => resolve(result);
      transaction.onerror = (event) => reject((event.target as IDBTransaction).error);
      transaction.onabort = () => reject(new Error('Transaction aborted.'));

      // Execute the operation
      try {
        const request: any = callback(transaction);
        if (request instanceof IDBRequest) {
          request.onsuccess = () => {
            result = request.result as T;
          };
          request.onerror = (event) => {
            console.error('Request error, aborting transaction:', (event.target as IDBRequest).error);
            transaction.abort();
          };
        }
      } catch (e) {
        reject(e);
        transaction.abort();
      }
    });
  }

  async add<T>(tableName: string, data: T): Promise<number> {
    return this._executeTransaction<number>([tableName], 'readwrite', (transaction) => {
      const store = transaction.objectStore(tableName);
      return store.add(data);
    });
  }

  async put<T>(tableName: string, data: T): Promise<number> {
    return this._executeTransaction<number>([tableName], 'readwrite', (transaction) => {
      const store = transaction.objectStore(tableName);
      return store.put(data);
    });
  }

  async addMetadata<T>(handler: EntityMetadataHandler, data: T): Promise<boolean> {
    const db = await this.dbService.getDb();
    return new Promise((resolve, reject) => {
      // Use all tables involved in the transaction
      const transaction = db.transaction(handler.getAllTablesName(), 'readwrite');
      const mainTableName = handler.metadata.dbTableName;
      const mainStore = transaction.objectStore(mainTableName);
      const entityToAdd: any = { ...data };

      // Flag to track if all related data additions are complete
      let relationsComplete = false;

      // 1. Handle related data
      handler.metadata.relations?.forEach(relation => {
        if (relation.apiKey && entityToAdd.hasOwnProperty(relation.apiKey)) {
          const relatedData = entityToAdd[relation.apiKey] ?? [];
          const relationStore = transaction.objectStore(relation.dbTableName);
          const relationMappingStore = transaction.objectStore(relation.mappingMetadata.dbTableName);

          relatedData.forEach((relatedEntity: any) => {
            // Add or update the related entity (e.g., User)
            relationStore.put(relatedEntity);

            // Add to the mapping table (e.g., ProjectMember)
            const mapRequest = relationMappingStore.put({
              [relation.mappingMetadata.parentPrimaryKey]: entityToAdd[handler.metadata.primaryKey as keyof T],
              [relation.mappingMetadata.childPrimaryKey]: relatedEntity[relation.primaryKey],
            });

            mapRequest.onerror = (event) => {
              const error = (event.target as IDBRequest).error;
              // Handle the expected ConstraintError from the 'unique_project_user' composite index
              if (error && error.name === 'ConstraintError') {
                console.warn(`Duplicate entry for ${relation.mappingMetadata.dbTableName}. Skipping.`);
              } else {
                // Abort for unexpected errors
                console.error('Unexpected error during mapping put:', error);
                transaction.abort();
              }
            };
          });
          // Remove related data from the main entity before storing
          delete (entityToAdd as any)[relation.apiKey];
        }
      });

      relationsComplete = true; // All relation puts have been initiated

      // 2. Add or update the main entity
      mainStore.put(entityToAdd);

      // 3. Resolve on Transaction Completion
      transaction.oncomplete = () => resolve(relationsComplete); // Will only resolve if all operations succeed

      transaction.onerror = (event) => reject((event.target as IDBTransaction).error);
      transaction.onabort = () => reject(new Error('Transaction aborted.'));
    });
  }

  // --- Helper Method to read all data from a store ---
  private getAllFromStore(store: IDBObjectStore, filter?: IndexFilter): Promise<any[]> {
    return new Promise((resolve, reject) => {
      let request: IDBRequest;

      if (filter) {
        // 1. Get the specific index
        const index = store.index(filter.indexName);

        // 2. Use the index's getAll method with the key range
        // This is the efficient way to filter data in IndexedDB.
        request = index.getAll(filter.keyRange);

      } else {
        // 3. Fallback to the original, unfiltered getAll on the store
        request = store.getAll();
      }
      request.onsuccess = (event) => resolve((event.target as IDBRequest).result);
      request.onerror = (event) => reject((event.target as IDBRequest).error);
    });
  }

  async getDataByMetadata<T>(handler: EntityMetadataHandler, filter?: IndexFilter): Promise<T[]> {
    const db = await this.dbService.getDb();
    return new Promise<T[]>(async (resolve, reject) => {
      // Use a single read-only transaction for all related stores
      const transaction = db.transaction(handler.getAllTablesName(), 'readonly');
      const mainTableName = handler.metadata.dbTableName;
      const mainStore = transaction.objectStore(mainTableName);

      // Get main entities first
      const mainDataList: any[] = await this.getAllFromStore(mainStore);

      // Attach related data to main entities
      const promises = mainDataList.map(async (mainEntity) => {
        if (handler.metadata.relations) {
          for (const relation of handler.metadata.relations) {
            const relationMappingStore = transaction.objectStore(relation.mappingMetadata.dbTableName);
            const relationStore = transaction.objectStore(relation.dbTableName);

            // Use the index on the mapping table for efficient filtering
            const indexName = relation.mappingMetadata.parentPrimaryKey as string;
            const mappingIndex = relationMappingStore.index(indexName);
            const key = mainEntity[handler.metadata.primaryKey as keyof T];

            // Get mapping records for the current main entity
            const mappingRecords: any[] = await new Promise((res, rej) => {
              const req = mappingIndex.getAll(key);
              req.onsuccess = () => res(req.result);
              req.onerror = () => rej(req.error);
            });

            // Collect the foreign keys (childPrimaryKeys)
            const childKeys = mappingRecords.map(m => m[relation.mappingMetadata.childPrimaryKey]);

            // Retrieve related entities by their keys
            const relatedEntities: any[] = [];
            for (const childKey of childKeys) {
              const relatedEntity = await new Promise((res, rej) => {
                const req = relationStore.get(childKey);
                req.onsuccess = () => res(req.result);
                req.onerror = () => rej(req.error);
              });
              if (relatedEntity) relatedEntities.push(relatedEntity);
            }

            if (relation.apiKey) {
              mainEntity[relation.apiKey] = relatedEntities;
            }
          }
        }
        return mainEntity;
      });

      // Wait for all entity enrichment to complete
      const enrichedData = await Promise.all(promises);

      transaction.oncomplete = () => resolve(enrichedData as T[]);
      transaction.onerror = (event) => reject((event.target as IDBTransaction).error);
      transaction.onabort = (event) => reject(new Error('Transaction aborted.'));

      // Note: Transaction needs to be active until all index/get requests are done.
      // Since we are awaiting promises (which release the thread), this approach
      // inside a single transaction loop is **dangerous** in IndexedDB's strict transaction model.
      // A better approach is to use a single large promise chain for reads or 
      // rely on the top-level transaction.oncomplete listener which handles the simple getAll/get requests fine.
      // The current implementation, while functional, relies on the asynchronous nature of IndexedDB requests 
      // being completed before the transaction is closed by the browser.
    });
  }

  async get<T>(tableName: string, key: IDBValidKey, api: Observable<any>): Promise<T | undefined> {
    const db = await this.dbService.getDb();
    let data: any = null;
    // First, try to get all data from IndexedDB
    try {
      data = await new Promise((resolve, reject) => {
        const transaction = db.transaction([tableName], 'readonly');
        const store = transaction.objectStore(tableName);
        const request = store.get(key);
        request.onsuccess = () => resolve(request.result as T | undefined);
        request.onerror = () => reject(request.error);
      });
    } catch (error) {
      console.error('IndexedDB getAll operation failed:', error);
    }

    // If no data is found locally, fetch from the API
    if (!data) {
      console.log('No data in IndexedDB. Fetching all from API:',);
      try {
        data = await new Promise<T>((resolve, reject) => {
          api.subscribe({
            next: (apiData) => {
              data = apiData as T;
              this.add(tableName, data);
              resolve(data);
            },
            error: (apiError) => {
              reject(apiError);
            }
          });
        });
      } catch (apiError) {
        console.error('API call failed:', apiError);
        throw apiError;
      }
    }

    return data;
  }

  async getAllByMetadata<T>(metadataKey: MetadataKeys, api: Observable<any>, filter?: IndexFilter): Promise<T[]> {
    const db = await this.dbService.getDb();
    let data: T[] = [];
    const metadataHandler = this.metadataService.getMetadata(metadataKey);
    // First, try to get all data from IndexedDB
    try {
      data = await this.getDataByMetadata<T>(metadataHandler, filter);
    } catch (error) {
      console.error('IndexedDB getAll operation failed:', error);
    }

    // If no data is found locally, fetch from the API
    if (!data || data.length === 0) {
      console.log('No data in IndexedDB. Fetching all from API:',);
      try {
        data = await new Promise<T[]>((resolve, reject) => {
          api.subscribe({
            next: (resp) => {
              const apiData = resp.list || resp;
              apiData.forEach((item: any) => this.addMetadata(metadataHandler, item));
              resolve(apiData as T[]);
            },
            error: (apiError) => {
              reject(apiError);
            }
          });
        });
      } catch (apiError) {
        console.error('API call failed:', apiError);
        throw apiError;
      }
    }
    return data;
  }

  async getAll<T>(tableName: string, api: Observable<any>): Promise<T[]> {
    const db = await this.dbService.getDb();
    let data: T[] = [];
    // First, try to get all data from IndexedDB
    try {
      data = await new Promise<T[]>((resolve, reject) => {
        const transaction = db.transaction([tableName], 'readonly');
        const store = transaction.objectStore(tableName);
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result as T[]);
        request.onerror = () => reject(request.error);
      });
    } catch (error) {
      console.error('IndexedDB getAll operation failed:', error);
    }

    // If no data is found locally, fetch from the API
    if (!data || data.length === 0) {
      console.log('No data in IndexedDB. Fetching all from API:',);
      try {
        data = await new Promise<T[]>((resolve, reject) => {
          api.subscribe({
            next: (resp) => {
              const apiData = resp.list || resp;
              apiData.forEach((item: any) => this.add(tableName, item));
              resolve(apiData as T[]);
            },
            error: (apiError) => {
              reject(apiError);
            }
          });
        });
      } catch (apiError) {
        console.error('API call failed:', apiError);
        throw apiError;
      }
    }

    return data;
  }
}
