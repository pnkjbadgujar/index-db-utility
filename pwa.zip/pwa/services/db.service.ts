import { Injectable } from '@angular/core';
import { INDEXDB_SCHEMA } from '../db-schema';

@Injectable({
  providedIn: 'root',
})
export class DbService {
  private db: IDBDatabase | null = null;
  private dbName = 'medprizm_pwa_db';
  // Increment this version number whenever INDEXDB_SCHEMA changes
  private dbVersion = 1; // Increased from 1 to 2 to trigger migration logic

  public async getDb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      if (this.db) {
        resolve(this.db);
        return;
      }
      const request = indexedDB.open(this.dbName, this.dbVersion);
      
      request.onerror = (event) => reject((event.target as IDBOpenDBRequest).error);
      
      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        resolve(this.db);
      };
      
      // Migration logic runs when the requested version is greater than the existing version
      request.onupgradeneeded = (event) => {
        console.log(`Upgrading database from version ${event.oldVersion} to ${event.newVersion}...`);
        this.db = (event.target as IDBOpenDBRequest).result;
        this.migrateSchema(this.db);
      };
    });
  }

  /**
   * Migrates/initializes object stores and their indexes based on the INDEXDB_SCHEMA array.
   * This is called inside request.onupgradeneeded.
   */
  private migrateSchema(db: IDBDatabase): void {
    const existingStoreNames = Array.from(db.objectStoreNames);

    // 1. Process Stores from Schema (Create or Update)
    for (const storeDef of INDEXDB_SCHEMA) {
      let objectStore: IDBObjectStore;

      if (!existingStoreNames.includes(storeDef.name)) {
        // A. New Store: Create it
        objectStore = db.createObjectStore(storeDef.name, storeDef.options);
        console.log(`[Schema Migration] Created Object Store: ${storeDef.name}`);
      } else {
        // B. Existing Store: Get it for index modification
        // Note: You cannot change a store's keyPath or autoIncrement after creation.
        // If these change, you must delete and recreate the store (risky for data).
        objectStore = (db as any).transaction.objectStore(storeDef.name);
      }

      const existingIndexNames = Array.from(objectStore.indexNames);

      // C. Process Indexes (Create or Update)
      for (const indexDef of storeDef.indexes) {
        if (!existingIndexNames.includes(indexDef.name)) {
          // New Index: Create it
          objectStore.createIndex(
            indexDef.name,
            indexDef.keyPath,
            indexDef.options || {}
          );
          console.log(`[Schema Migration] Created Index: ${indexDef.name} on ${storeDef.name}`);
        }
        // Complex index changes (keyPath/unique changes) are omitted here for brevity
        // but would require deleting and recreating the index.
      }

      // D. Delete Obsolete Indexes
      existingIndexNames.forEach(indexName => {
        if (!storeDef.indexes.some(def => def.name === indexName)) {
          objectStore.deleteIndex(indexName);
          console.log(`[Schema Migration] Deleted Obsolete Index: ${indexName} on ${storeDef.name}`);
        }
      });
    }

    // 2. Delete Obsolete Stores
    existingStoreNames.forEach(storeName => {
      if (!INDEXDB_SCHEMA.some(def => def.name === storeName)) {
        db.deleteObjectStore(storeName);
        console.log(`[Schema Migration] Deleted Obsolete Object Store: ${storeName}`);
      }
    });
  }

  clearDatabase(): Promise<void> {
    return new Promise((resolve, reject) => {
      const deleteRequest = indexedDB.deleteDatabase(this.dbName);
      deleteRequest.onsuccess = () => {
        console.log('Database cleared successfully.');
        this.db = null; // Reset the db reference
        resolve();
      };
      deleteRequest.onerror = (event) => {
        console.error('Error clearing database:', (event.target as IDBRequest).error);
        reject((event.target as IDBRequest).error);
      };
    });
  }
}